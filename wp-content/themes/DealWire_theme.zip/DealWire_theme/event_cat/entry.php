<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <?php
        get_template_part('event_cat/entry','summary');
    ?>
</div>