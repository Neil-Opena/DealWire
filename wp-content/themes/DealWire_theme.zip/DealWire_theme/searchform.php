<form method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	<div id="search-inputs">
		<input type="text" value="" name="s" id="s" placeholder="What are you looking for?" />
		<input type="submit" id="searchsubmit" value="" />
	</div>
</form>